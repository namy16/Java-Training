/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class NewServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
                
        Connection ct = DriverManager.getConnection("jdbc:mysql://localhost/kkkk","root","abcdfe");
        
        Statement st = ct.createStatement();
        
        ResultSet rs = st.executeQuery("select * from students");
        
        while(rs.next())
        {
            int jid = rs.getInt("id");
            
            String jnam = rs.getString("sname");
            
            pw.println("<br>Id:"+jid);
            
            pw.println("<br>Name:"+jnam);
        }
        
        rs.close();
        st.close();
        ct.close();
        }
        catch(Exception et)
        {
            et.printStackTrace();
        }
    }



}
