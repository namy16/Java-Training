/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
//ServletException is thrown, if any run time error occurs while executing servlet

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
//HttpServletRequest holds all the request data recvd from Browser
//HttpServletResponse holds response details which are being sent to Browser from Servlet

import javax.servlet.http.HttpServletResponse;

public class NewServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter pw = response.getWriter();
        
        pw.println("<center><h1>Hello How are you?</h1><center>");
        
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}
