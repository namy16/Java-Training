/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;

/**
 *
 * @author ADMIN
 */
public class ServletAllParameters extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
    }
    
    public void processRequest(HttpServletRequest req,HttpServletResponse res) 
            throws IOException{
    Enumeration paramNames = req.getParameterNames(); 
    PrintWriter pw = res.getWriter();
    
    pw.println("<br><font color=\"#FF0000\">Can u see this message from servlet</font>");
    int i = 1;
    String paramName; 
    while(paramNames.hasMoreElements()) 
    { 
        paramName = (String)paramNames.nextElement(); 
        pw.print("<br>"+i+" "+paramName+":"); 
        i++;
        String paramValue = req.getParameter(paramName); 
        pw.print("<i>"+paramValue + "</i><br>"); 
    }  
    }
}
