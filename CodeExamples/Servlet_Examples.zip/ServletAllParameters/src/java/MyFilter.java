import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.*;  
  
public class MyFilter implements Filter{  
  
public void init(FilterConfig xyz) throws ServletException 
{
    //arg0.getInitParameter("");
    System.out.println("init() in MyFilter");
}  
      
public void doFilter(ServletRequest req, ServletResponse resp,  
    FilterChain chain) throws IOException, ServletException {  
          
    PrintWriter out=resp.getWriter();  
     
          
   if(req.getRemoteAddr().equals("127.0.0.1"))
    {
        out.print("Your IP addr is blocked. Retry later"); 
        return;
    }
    
    out.print("<br>111111111111111myfilter is invoked before"); 
    chain.doFilter(req, resp);//sends request to next resource  
          
    out.print("<br>111111111111111111myfilter is invoked after");  
    
    System.out.println("doFilter() in MyFilter");
    }  

public void destroy() {
    System.out.println("destroy() in MyFilter");
    }  
} 