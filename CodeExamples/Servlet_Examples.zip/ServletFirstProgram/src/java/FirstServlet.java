
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FirstServlet extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       PrintWriter pw = response.getWriter();
       pw.println("Can you see this doGet output on the Browser?");
               
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
               PrintWriter pw = response.getWriter();
       pw.println("<html><body><font color=\"#00FF00\" size=\"20\">Can u see this text</font> ");
       pw.println("<br><a href=\"\">Can u see this hyper link</a></body></html>");

    }
}
