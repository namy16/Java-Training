/**
 * Created by ADMIN on 7/28/17.
 */
public class ArithBusinessLogic {
    private int a, b;
    ArithBusinessLogic(int a, int b)
    {
        this.a = a;
        this.b = b;
    }

    int add()
    {
        return a+b;
    }

    int sub()
    {
        return a-b;
    }

    int mul()
    {
        return a*b;
    }
}
