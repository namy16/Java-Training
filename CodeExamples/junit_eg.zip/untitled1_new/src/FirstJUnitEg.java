/**
 * Created by ADMIN on 7/2/17.
 */
import org.junit.After;
import org.junit.AfterClass;

import org.junit.Before;
import org.junit.BeforeClass;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.Assert;

public class FirstJUnitEg {

    static ArithBusinessLogic obj;

    //execute before class
    @BeforeClass
    public static void beforeClass() {
        System.out.println("in before class");
        obj = new ArithBusinessLogic(10,20);
    }

    //execute after class
    @AfterClass
    public static void  afterClass() {
        System.out.println("in after class");
    }

    //execute before test
    @Before
    public void before() {
        System.out.println("in before");

    }

    //execute after test
    @After
    public void after() {
        System.out.println("in after");
    }

    //test case
    @Test
    public void test1() {
        Assert.assertEquals(obj.add(), 30);

        System.out.println("in test1");

    }

    //test case
    @Test
    public void test2() {
        Assert.assertEquals(obj.sub(), -10);
        System.out.println("in test2");
    }

    //test case ignore and will not execute
    @Ignore
    public void ignoreTest() {
        System.out.println("in ignore test");
    }
}