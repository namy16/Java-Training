package com.test;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "user")
public class User implements Serializable {

   private static final long serialVersionUID = 1L;
   private int id;
   private String name;
   private String profession;
   private String addr;

   public String getAddr() {
	return addr;
}

   @XmlElement
public void setAddr(String addr) {
	this.addr = addr;
}

public User(){}

   public User(int id, String name, String profession, String addr){
      this.id = id;
      this.name = name;
      this.profession = profession;
      this.addr = addr;
   }

   public int getId() {
      return id;
   }
   @XmlElement
   public void setId(int id) {
      this.id = id;
   }
   public String getName() {
      return name;
   }
   @XmlElement
      public void setName(String name) {
      this.name = name;
   }
   public String getProfession() {
      return profession;
   }
   @XmlElement
   public void setProfession(String profession) {
      this.profession = profession;
   }	
   
   @Override
   public String toString()
   {
	   return id+" "+name+" "+profession+" "+addr;
   }

   @Override
   public boolean equals(Object object){
      if(object == null){
         return false;
      }else if(!(object instanceof User)){
         return false;
      }else {
         User user = (User)object;
         if(id == user.getId()
            && name.equals(user.getName())
            && profession.equals(user.getProfession())
            && addr.equals(user.getAddr())
         ){
            return true;
         }			
      }
      return false;
   }	
}
