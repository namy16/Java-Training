package com.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

public class WebServiceTester  {

   private Client client;//RestfulExample1/rest/
   private String REST_SERVICE_URL = "http://localhost:8080/RestfulExample1/rest/UserService/users";
   private static final String SUCCESS_RESULT="<result>success</result>";
   private static final String PASS = "pass";
   private static final String FAIL = "fail";

   private void init(){
      this.client = ClientBuilder.newClient();
   }

   public static void main(String[] args){
      WebServiceTester tester = new WebServiceTester();
      //initialize the tester
      tester.init();

      tester.testSendXMLObject();
      
      System.exit(0);
      
      tester.testOptions();
      tester.testAddUserQP();
      tester.testQueryParam();
      
      tester.testUpdateAddr();
      
    //test update user Web Service Method
      tester.testUpdateUser();
      
      //test get user Web Service Method 
      tester.testGetUser();
      
      tester.testGetAllUsersJSON();
      
      
      //test add user Web Service Method
      tester.testAddUser2();
      tester.testAddUser3();
      
      
      
      System.out.println("Before Deletion--------");
      //test get all users Web Service Method
      tester.testGetAllUsers();
      //test delete user Web Service Method
      tester.testDeleteUser();
      System.out.println("After Deletion--------");
      //test get all users Web Service Method
      tester.testGetAllUsers();
   }
   
   private void testSendXMLObject(){
	   User usr = new User(15, "some name", "some profession", "some addr");
   WebTarget target = client.target("http://localhost:8080/RestfulExample1/rest/UserService/usersent");
   String response = target.request(MediaType.APPLICATION_XML)
                           .accept(MediaType.APPLICATION_XML)
                           .post(Entity.xml(usr), String.class);//similarly Entity.json() can be used
   
   System.out.println("testSendXMLObject():"+response);
   }
   
   //Test: Get list of all users
   //Test: Check if list is not empty
   private void testGetAllUsersJSON(){
      GenericType<List<User>> list = new GenericType<List<User>>() {};
      List<User> users = client
         .target("http://localhost:8080/RestfulExample1/rest/UserService/usersjs")
         .request(MediaType.APPLICATION_JSON)
         .get(list);
      String result = PASS;
      if(users.isEmpty()){
         result = FAIL;
      }
      
      for(User usr:users)
      {
    	  System.out.println(usr);
      }
      System.out.println("Test case name: testGetAllUsersJSON, Result: " + result );
   }
   
   private void testQueryParam(){
	     GenericType<List<User>> list = new GenericType<List<User>>() {};
	     List<User> users  = client
	         .target("http://localhost:8080/RestfulExample1/rest/UserService/usersqp?start=1&nums=10")
	         .request(MediaType.APPLICATION_XML).get(list);

	      System.out.println("Test case name: testQueryParam" );
   }
   
   //Test: Get list of all users
   //Test: Check if list is not empty
   private void testGetAllUsers(){
      GenericType<List<User>> list = new GenericType<List<User>>() {};
      List<User> users = client
         .target(REST_SERVICE_URL)
         .request(MediaType.APPLICATION_XML)
         .get(list);
      String result = PASS;
      if(users.isEmpty()){
         result = FAIL;
      }
      
      for(User usr:users)
      {
    	  System.out.println(usr);
      }
      System.out.println("Test case name: testGetAllUsers, Result: " + result );
   }
   //Test: Get User of id 1
   //Test: Check if user is same as sample user
   private void testGetUser(){
      User sampleUser = new User();
      sampleUser.setId(1);

      User user = client
         .target(REST_SERVICE_URL)
         .path("/{userid}")
         .resolveTemplate("userid", 1)
         .request(MediaType.APPLICATION_XML)
         .get(User.class);
      String result = FAIL;
      if(sampleUser != null && sampleUser.getId() == user.getId()){
         result = PASS;
      }
      System.out.println("Test case name: testGetUser, Result: " + result );
   }
   
   //public String updateAddr(@FormParam("id") int id, @FormParam("uaddr") String uaddr)
   private void testUpdateAddr(){
	   Form form = new Form();
	   form.param("id", "6");
	   form.param("uaddr", "MArathahalli");
	   
	   String str = client.target("http://localhost:8080/RestfulExample1/rest/UserService/usersu")
	   .request(MediaType.APPLICATION_XML).put(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED_TYPE),
            String.class);
	   
	   System.out.println("Addr updated Result:"+str);
   }
   //Test: Update User of id 1
   //Test: Check if result is success XML.
   private void testUpdateUser(){
      Form form = new Form();
      form.param("id", "1");
      form.param("name", "suresh");
      form.param("profession", "clerk");
      form.param("addr", "WhiteField");

      String callResult = client
         .target(REST_SERVICE_URL)
         .request(MediaType.APPLICATION_XML)
         .put(Entity.entity(form,
            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
            String.class);
      String result = PASS;
      if(!SUCCESS_RESULT.equals(callResult)){
         result = FAIL;
      }

      System.out.println("Test case name: testUpdateUser, Result: " + result );
   }
   
   //Test: Add User of id 2
   //Test: Check if result is success XML.
   private void testAddUserQP(){
      String callResult = client
         .target("http://localhost:8080/RestfulExample1/rest/UserService/usersqpp/10/Ravi/srmgr/btm") //or resolveTemplate can be used
         .request(MediaType.APPLICATION_XML)
         .get(String.class);
   
      String result = PASS;
      if(!SUCCESS_RESULT.equals(callResult)){
         result = FAIL;
      }

      System.out.println("Test case name: testAddUserQP, Result: " + result );
   }
   
   
   //Test: Add User of id 2
   //Test: Check if result is success XML.
   private void testAddUser2(){
	   
	   //Creating Form params, which can be retrieved on Server using @FormParam
      Form form = new Form();
      form.param("id", "6");
      form.param("name", "abcdef");
      form.param("profession", "managerr");
      form.param("addr", "Jayanagar");

      String callResult = client
         .target(REST_SERVICE_URL)
         .request(MediaType.APPLICATION_XML)
         .post(Entity.entity(form,
            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
            String.class);
   
      String result = PASS;
      if(!SUCCESS_RESULT.equals(callResult)){
         result = FAIL;
      }

      System.out.println("Test case name: testAddUser2, Result: " + result );
   }
   //Test: Add User of id 3
   //Test: Check if result is success XML.
   private void testAddUser3(){
      Form form = new Form();
      form.param("id", "8");
      form.param("name", "kumar");
      form.param("profession", "manager");
      form.param("addr", "Hebbal");

      String callResult = client
         .target(REST_SERVICE_URL)
         .request(MediaType.APPLICATION_XML)
         .post(Entity.entity(form,
            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
            String.class);
   
      String result = PASS;
      if(!SUCCESS_RESULT.equals(callResult)){
         result = FAIL;
      }

      System.out.println("Test case name: testAddUser3, Result: " + result );
   }
   //Test: Delete User of id 2
   //Test: Check if result is success XML.
   private void testDeleteUser(){
      String callResult = client
         .target(REST_SERVICE_URL)
         .path("/{userid}")
         .resolveTemplate("userid", 8)
         .request(MediaType.APPLICATION_XML)
         .delete(String.class);

      String result = PASS;
      if(!SUCCESS_RESULT.equals(callResult)){
         result = FAIL;
      }

      System.out.println("Test case name: testDeleteUser, Result: " + result );
   }
   
   
   private void testOptions(){
      String callResult = client
         .target(REST_SERVICE_URL)
         .request(MediaType.APPLICATION_XML).options(String.class);

      System.out.println("Test case name: testOptions, Result: " + callResult );
   }
}
