package com.tst;

import java.io.*;
import java.net.URI;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

/**
 * Servlet implementation class RESTServletClient
 */
@WebServlet("/RESTServletClient")
public class RESTServletClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final String webServiceURI = "http://localhost:8080/RESTFirstExample";
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RESTServletClient() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw = response.getWriter();
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
		WebTarget webTarget = client.target(serviceURI);

		// text
		/*System.out.println(webTarget.path("rest").path("helloworlds").request()
				.accept(MediaType.TEXT_PLAIN) //client expects plain text
				.get(String.class)); //client sends thru HTTP GET Method
				*/

		// xml
		pw.println(webTarget.path("rest").path("helloworlds").request()
				.accept(MediaType.TEXT_XML) //client expects XML text
				.get(String.class)); //client sends thru HTTP GET Method

		pw.println("<BR>");
		// html
		pw.println(webTarget.path("rest").path("helloworlds").request()
				.accept(MediaType.TEXT_HTML)  //client expects html text
				.get(String.class)); //client sends thru HTTP GET Method
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
