
public class Module2 {
	public void met2()
	{
		System.out.println("met2() in Module2");
	}
}
