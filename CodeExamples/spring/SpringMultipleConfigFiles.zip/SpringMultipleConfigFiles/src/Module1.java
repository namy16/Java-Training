
public class Module1 {
	String str;
	public void met1()
	{
		System.out.println("met1() in MOdule1");
	}
}
