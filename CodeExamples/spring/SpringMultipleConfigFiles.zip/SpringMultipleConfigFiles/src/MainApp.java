import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;  
  
public class MainApp {  
    public static void main(String[] args) {  
          
        Resource r=new ClassPathResource("applicationConfig.xml");  
        BeanFactory factory=new XmlBeanFactory(r);  
          
        Module1 m1=(Module1)factory.getBean("mod1");  
        m1.met1();
        
        Module2 m2=(Module2)factory.getBean("mod2");  
        m2.met2();
          
    }  
}

