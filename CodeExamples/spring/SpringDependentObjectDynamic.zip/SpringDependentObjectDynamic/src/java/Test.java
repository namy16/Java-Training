import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  
  
public class Test {  
public static void main(String[] args) {  
    Resource r=new ClassPathResource("applicationContext.xml");  
    BeanFactory factory=new XmlBeanFactory(r);  
     
    Address adr=(Address)factory.getBean("address1", "Xyz rd","Marathalli","Bangalore","India");   
    System.out.println("Check:"+adr.toString());
    
    Employee e=(Employee)factory.getBean("obj",23,"fdsf",adr);  
    e.displayInfo();  
      
}  
}