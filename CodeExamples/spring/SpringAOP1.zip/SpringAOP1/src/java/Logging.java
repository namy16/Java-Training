import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.AfterThrowing;

@Aspect
public class Logging {

   @Before("execution(* *.so*(..))")
    public synchronized void bAdvice(JoinPoint jp){
      System.out.println("bbbbbbbefore Advice invoked"
              +jp.getSignature().getName());
   }
   
     @After("execution(* *.*(..))")
   public void aAdvice(){
      System.out.println("after Advice1 invoked\n");
   }
   
  @Around("execution(* *.*(..))")
   public void adAdvice(){
       System.out.println("Around Advice called\n");
   }

}