package com.opencredo.demo.hateoas.api.resources;

public class NewPublisher {
   
   private String name;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
   
}
