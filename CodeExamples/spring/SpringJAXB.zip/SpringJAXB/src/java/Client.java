import java.io.FileWriter;  
import java.io.IOException;  
import javax.xml.transform.stream.StreamResult;  
import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;  
import org.springframework.oxm.Marshaller;  
  
public class Client{  
 public static void main(String[] args)throws IOException{  
  ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");  
  Marshaller marshaller = (Marshaller)context.getBean("jaxbMarshallerBean");  
          
  Employee employee=new Employee();  
  Address add = new Address();
  add.setId(1);
  add.setCity("BANGALORE");
  add.setPostCode(560100);
  employee.setId(102);  
  employee.setName("Some Test purpose");  
  employee.setSalary(400000);  
  employee.setAge(25);
  employee.setAddress(add);
          
  marshaller.marshal(employee, new StreamResult(new FileWriter("employee.xml")));  
  marshaller.marshal(employee, new StreamResult(System.out)); 
  
  System.out.println("XML Created Sucessfully");  
 }  
}  
