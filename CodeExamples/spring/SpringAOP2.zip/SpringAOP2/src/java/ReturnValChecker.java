import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.framework.ProxyFactory;

public class ReturnValChecker implements AfterReturningAdvice{

private ProxyFactory pf;

    public ReturnValChecker(ProxyFactory pf)
    {
        this.pf=pf;
    }

    @Override
    public void afterReturning(Object returnValue, Method method, Object[] args,
            Object target) throws Throwable {
        
        int i=(Integer)returnValue;
        
            if(i==1)
            {
                System.out.println("i=1, so calling "+method.getName()+"() again");
                WorkerBean bean=(WorkerBean)pf.getProxy();
                bean.generateRandomInt();
            }
            else
            {
                System.out.println("i is greater than 1, no problem!");
            }
    }
}