import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.framework.ProxyFactory;

public class SpringPrg {

    public static void main(String args[])
    {
        // Create bean object
        WorkerBean wb=new WorkerBean();
        
        // Create a ProxyFactory object
        ProxyFactory pf=new ProxyFactory();
        
        // Create advice object
        AfterReturningAdvice rc=new ReturnValChecker(pf);
        
        // Set the target object
        pf.setTarget(wb);

        // Add advice
        pf.addAdvice(rc);
        
        // Get the proxied bean object
        WorkerBean bean=(WorkerBean)pf.getProxy();
        
        // Start the work
        bean.generateRandomInt();
    }
}