/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class XyzEmployee  implements IEmployee{
    private int id;  
private String name;  
  private String fName;  
  
public XyzEmployee() 
{
    System.out.println("Xyz def cons");
}  
  
public XyzEmployee(int id) 
{
    this.id = id;
    System.out.println("XyzEmployee(int id)");
}  
  
public XyzEmployee(String name) 
{  
    this.name = name;
    System.out.println("XyzEmployee(String str)");
}  
  
public XyzEmployee(int id, String name, String fName) {  
    this.id = id;  
    this.name = name;  
    this.fName = fName;
    System.out.println("XyzEmployee(int id, String name, String fnaME)");
} 
  
/*public Employee(String name,int id) {  
    this.id = id;  
    this.name = name;  
    System.out.println("using interface Employee(int id, String name)");
} */

public void show(){  
    System.out.println("show() method in XyzEmployee");
    System.out.println(id+" "+name+" "+fName);  
}  
}
