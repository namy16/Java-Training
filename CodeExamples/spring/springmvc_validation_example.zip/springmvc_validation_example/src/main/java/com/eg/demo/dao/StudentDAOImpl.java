package com.eg.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.eg.demo.model.StudentVO;
import org.springframework.stereotype.Repository;

@Repository
public class StudentDAOImpl implements StudentDAO {

	//returning list of dummy data, instead data can be retrieved from database or else where
	public List<StudentVO> getAllStudents()
	{
		List<StudentVO> students = new ArrayList<StudentVO>();
		
		StudentVO vo1 = new StudentVO();
		vo1.setId(1);
		vo1.setFirstName("sukumar");
		vo1.setLastName("abc");
		students.add(vo1);
		
		StudentVO vo2 = new StudentVO();
		vo2.setId(2);
		vo2.setFirstName("kiran");
		vo2.setLastName("kumar");
		students.add(vo2);
		
		return students;
	}
}