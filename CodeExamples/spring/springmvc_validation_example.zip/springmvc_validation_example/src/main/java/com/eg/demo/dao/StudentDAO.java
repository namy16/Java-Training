package com.eg.demo.dao;

import java.util.List;

import com.eg.demo.model.StudentVO;

public interface StudentDAO
{
	public List<StudentVO> getAllStudents();
}