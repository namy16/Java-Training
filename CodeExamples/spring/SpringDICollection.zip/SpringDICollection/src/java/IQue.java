
public interface IQue {
    public void displayInfo();
}
