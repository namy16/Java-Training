public class Employee {  
private int id;  
private String name;  
private String city;  
  
public Employee(){
    System.out.println("Employee()");
}
public int getId() {  
    return id;  
}  
public void setid(int id) {  
    this.id = id;  
    System.out.println("setting id");
}
public String getName() {  
    return name;  
}  
public void setName(String name) {  
    this.name = name;  
    System.out.println("setting name");
}  
  
public String getCity() {  
    return city;  
}  
public void setCity(String city) {  
    this.city = city;  
    System.out.println("setting city");
}  
void display(){  
    System.out.println(id+" "+name+" "+city);  
}  
  
}