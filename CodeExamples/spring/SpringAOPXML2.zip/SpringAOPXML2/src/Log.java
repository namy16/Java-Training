

public class Log{

   public void beforeAdvice(){
      System.out.println("before Advice invokedddddddddddd");
   }
  
   public void afterAdvice(){
      System.out.println("after Advice1 invokedddddddddddddddd");
   }

   /* There can be multiple After Advices */
   public void afterAdviceXYZ(){
      System.out.println("after Advice 2.tttttttttttttttttttttttttttttttttttttttttttttttttt");
   }
   
   public void afterAdvice1() {
       System.out.println("After Advice1...");
   }
   
      /** 
    * This is the method which I would like to execute
    * when any method returns.
    */
   public void afterReturningAdvice(Object retVal){
      System.out.println("Returning:");
   }

   /**
    * This is the method which I would like to execute
    * if there is an exception raised by any method.
    */
   public void AfterThrowingAdvice(IllegalArgumentException ex){
      System.out.println("There has been an exception: " + ex.toString());   
   }
}