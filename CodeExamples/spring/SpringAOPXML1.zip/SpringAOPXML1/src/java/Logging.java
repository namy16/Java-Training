import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;


public class Logging {

   /** Following is the definition for a pointcut to select
    *  all the methods available. So advice will be called
    *  for all the methods.
    */
//@Pointcut("execution(* *.test*(..))") //methods starting with test
   //@Pointcut("execution(* *.*(..))")
    private void selectAll(){
   }

   /** 
    * This is the method which I would like to execute
    * before a selected method execution.
    */
   public void beforeAdvice(){
      System.out.println("before Advice invokedddddddddddd");
   }

   /** 
    * This is the method which I would like to execute
    * after a selected method execution.
    */
  
   public void afterAdvice(){
      System.out.println("after Advice1 invokedddddddddddddddd");
   }

   /* There can be multiple After Advices */
   public void afterAdviceXYZ(){
      System.out.println("after Advice 2.tttttttttttttttttttttttttttttttttttttttttttttttttt");
   }
   
   public void afterAdvice1() {
       System.out.println("After Advice1...");
   }
   
      /** 
    * This is the method which I would like to execute
    * when any method returns.
    */
   public void afterReturningAdvice(Object retVal){
      System.out.println("Returning:");
   }

   /**
    * This is the method which I would like to execute
    * if there is an exception raised by any method.
    */
   public void AfterThrowingAdvice(IllegalArgumentException ex){
      System.out.println("There has been an exception: " + ex.toString());   
   }
}