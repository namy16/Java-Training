package com.xyz.helloworld.controller;

/**
 * Created by ADMIN on 7/29/17.
 */
@SuppressWarnings("unchecked")
public class User {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
