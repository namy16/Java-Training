import java.util.*;

public class Trainer{
   private int id;
   private String firstName; 
   private String lastName;   
   private int salary;
   private Student student_obj; //one to one mapping

   public Trainer() {}
   public Trainer(String fname, String lname, 
                   int salary, Student student_obj ) {
      this.firstName = fname;
      this.lastName = lname;
      this.salary = salary;
      this.student_obj = student_obj;
   }
   public int getId() {
      return id;
   }
   public void setId( int id ) {
      this.id = id;
   }
   public String getFirstName() {
      return firstName;
   }
   public void setFirstName( String first_name ) {
      this.firstName = first_name;
   }
   public String getLastName() {
      return lastName;
   }
   public void setLastName( String last_name ) {
      this.lastName = last_name;
   }
   public int getSalary() {
      return salary;
   }
   public void setSalary( int salary ) {
      this.salary = salary;
   }

   public Student getStudent() {
      return student_obj;
   }
   public void setStudent( Student student_obj ) {
      this.student_obj = student_obj;
   }
}