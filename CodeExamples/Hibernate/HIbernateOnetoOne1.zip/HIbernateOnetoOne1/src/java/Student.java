import java.util.*;

public class Student{
   private int id;
   private String sName; 
   private String sPhone;   

   public Student() {}
   public Student(String sName, String sPhone ) {
      this.sName = sName;
      this.sPhone = sPhone;
   }
   public int getId() {
      return id;
   }
   public void setId( int id ) {
      this.id = id;
   }
   public String getSName() {
      return sName;
   }
   public void setSName( String sName ) {
      this.sName = sName;
   }
   public String getSPhone() {
      return sPhone;
   }
   public void setSPhone( String sPhone ) {
      this.sPhone = sPhone;
   }
 
}