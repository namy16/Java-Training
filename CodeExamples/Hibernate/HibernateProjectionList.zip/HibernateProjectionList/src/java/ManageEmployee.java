/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
import java.util.List; 
import java.util.Date;
import java.util.Iterator; 
 
import org.hibernate.HibernateException; 
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.ProjectionList;

public class ManageEmployee {
   private static SessionFactory factory; 
   public static void main(String[] args) {
      try{
         factory = new Configuration().configure().buildSessionFactory();
      }catch (Throwable ex) { 
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex); 
      }
      ManageEmployee ME = new ManageEmployee();

      /* List down all the employees */
      ME.listEmployees();

   }

  /* Method to  READ all the employees */
   public void listEmployees( ){
      Session session = factory.openSession();
      Transaction tx = null;
      try{
         tx = session.beginTransaction();

         Criteria crit = session.createCriteria(Employee.class);
         
         //to get count of firstName
         Criteria criteria = session.createCriteria(Employee.class);
	criteria.setProjection(Projections.count("firstName"));
	List list = criteria.list();
	System.out.println("Number of rows with firstNames is = " + list.get(0));
        
         //To select multiple columns
         ProjectionList proList = Projections.projectionList(); 
         proList.add(Projections.property("firstName")); 
         proList.add(Projections.property("lastName")); 
         crit.setProjection(proList); 
         List course = crit.list(); 
         for (Iterator it = course.iterator(); it.hasNext();) 
         { 
             //get the row
            Object[] row = (Object[]) it.next(); 
         
            for (int i = 0; i < row.length; i++) 
            { 
                System.out.print("col:"+row[i]+" "); 
            } 
            
            System.out.println();
         }

         tx.commit();
      }catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      }finally {
         session.close(); 
      }
   }
}
