
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.util.*;
 
public class Main {
 
    public static void main(String[] args) {
 
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();
 
        
        Meeting1 meeting1 = new Meeting1("first meting");
        Meeting1 meeting2 = new Meeting1("one moree meeting");
        
        Employee employee1 = new Employee("Sergey", "Brin");
        Employee employee2 = new Employee("Larry", "Page");

        HashSet hs = new HashSet();
        hs.add(meeting1);
        hs.add(meeting2);
        
        /*employee2.getMeetings().add(meeting1);
        */
        session.save(employee1);
        //session.save(employee2);
        
        session.getTransaction().commit();
        session.close();
    }
}