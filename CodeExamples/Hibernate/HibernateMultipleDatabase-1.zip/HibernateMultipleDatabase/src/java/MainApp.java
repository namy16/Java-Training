/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
import java.util.List; 
import java.util.Date;
import java.util.Iterator; 
 
import org.hibernate.HibernateException; 
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

public class MainApp {
   private static SessionFactory factory1, factory2; 
   
   public static void main(String[] args) {
      try{
         factory1 = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        factory2 = new Configuration().configure("hibernate1.cfg.xml").buildSessionFactory();

      }catch (Throwable ex) { 
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex); 
      }
      MainApp ME = new MainApp();

      /* Add few employee records in database */
      Integer empID1 = ME.addEmployee("testname1", "Ali", 8000);
      Integer empID2 = ME.addEmployee("testname2", "Das", 9000);
      Integer empID3 = ME.addEmployee("testname3", "Paul", 11000);

   }
   /* Method to CREATE an employee object in the database */
   public Integer addEmployee(String fname, String lname, int salary){
      Session session1 = factory1.openSession();
      Transaction tx = null;
      Integer employeeID = null;
      try{
         tx = session1.beginTransaction();
         Employee employee = new Employee(fname, lname, salary);
         employee.setDept("testdpt");
         employeeID = (Integer) session1.save(employee); 
         tx.commit(); //commit db changes if everything went fine
      }catch (HibernateException e) {
         if (tx!=null) tx.rollback(); //rollback db changes if any exception
         e.printStackTrace(); 
      }finally {
         session1.close(); 
      }
      
            Session session2 = factory2.openSession();
      Transaction tx1 = null;
      Integer employeeID1 = null;
      try{
         tx = session2.beginTransaction();
         Employee employee = new Employee(fname, lname, salary);
         employee.setDept("testdpt");
         employeeID = (Integer) session2.save(employee); 
         tx.commit(); //commit db changes if everything went fine
      }catch (HibernateException e) {
         if (tx!=null) tx.rollback(); //rollback db changes if any exception
         e.printStackTrace(); 
      }finally {
         session2.close(); 
      }
      
      return employeeID;
   }
}
