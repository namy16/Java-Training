
public interface test1 {
	public void met1();
	
	public int met2();
}
