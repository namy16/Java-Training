
public class MainClass {
	public static void main(String args[])
	{
		Impls obj = new Impls();
		
		obj.met1();
		
		obj.met5();
		
		System.out.println("PI vlaue is:"+jft.PI);
	}
}
