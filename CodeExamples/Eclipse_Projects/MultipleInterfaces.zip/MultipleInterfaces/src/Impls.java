
public class Impls implements test1, jft{
	public void met1(){
		System.out.println("met1() in Impls class");
	}
	
	public int met2(){
		System.out.println("met2() in Impls class");
		
		return 1;
	}
	
	public float met5(){
		System.out.println("met5() in Impls class");
		
		return 5.6f;
	}
}
