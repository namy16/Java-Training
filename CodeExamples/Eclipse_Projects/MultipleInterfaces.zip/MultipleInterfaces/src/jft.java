
interface jft {
	final float PI = 3.14f;
	//constants can be declared in interface
	
	float met5();
}
