
class Holder<K, T>
{
	K ok;
	T ot;
	
	//add constructor, set/get
}

class A8{}

class B8{}

public class GenericMultipleTypeParams {
	public static void main(String[] args) {
		Holder<A8, B8> obj = new Holder<A8, B8>();
		
		
	}
}
