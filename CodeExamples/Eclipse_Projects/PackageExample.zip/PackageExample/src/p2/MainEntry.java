package p2;

import p1.Abc;

public class MainEntry {
	public static void main(String abc[]) {
		Abc obj = new Abc();
		//obj.met1(); //Compile time error, since met1 is default
		
		obj.met2();
	}
}
