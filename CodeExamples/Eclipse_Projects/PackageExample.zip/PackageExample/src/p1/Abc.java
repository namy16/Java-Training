package p1;

public class Abc {
	void met1()
	{
		System.out.println("met1() in Abc class");
	}
	
	public void met2()
	{
		met1();
		System.out.println("met2() in Abc class");
	}
}
