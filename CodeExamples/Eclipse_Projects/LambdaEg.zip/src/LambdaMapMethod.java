import java.util.Arrays;
import java.util.stream.Stream;

/**
 * Created by ADMIN on 7/2/17.
 */
public class LambdaMapMethod {

    public static void main(String args[]) {
        String[] myArray = new String[]{"raju", "kiran", "ramu", "ravi"};
        Stream<String> myStream = Arrays.stream(myArray);

        Stream<String> myNewStream =
                myStream.map(s -> s.toUpperCase());

        myNewStream.forEach((item)->{System.out.println(item);});


        Stream<String> myNewStream1 =
                myStream.filter((s) ->s.length()<=4 );

        myNewStream.forEach((item)->{System.out.println(item);});
    }
}
