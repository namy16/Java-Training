/**
 * Created by ADMIN on 7/5/17.
 */

class Circle{
double r;
static double pi = 3.14;

Circle(double radius)
{
    r = radius;
}

double getSArea()
{
    double tmp;
    tmp = pi * r*r;

    return tmp;
}


double getCF()
{
    double tmp;
    tmp = 2*pi*r;

    return tmp;
}
}

public class CircleEg
{
    public static void main(String []args)
    {
        Circle obj = new Circle(4.5);

        double sa = obj.getSArea();

        System.out.println("Area is"+sa);
    }
}



