/**
 * Created by ADMIN on 7/5/17.
 */
class NotificationBar{
    static NotificationBar ref;

    private NotificationBar()
    {
        System.out.println("NotificationBar() invoked");
    }

    static NotificationBar getInstance(){
        if(ref==null)
        {
            ref = new NotificationBar();
        }
        else
        {
            System.out.println("Returning existing isntance");
        }

        return ref;
    }
}

public class SingletonEg {
    public static void main(String args[])
    {
        NotificationBar nb = NotificationBar.getInstance();

        NotificationBar nb1 = NotificationBar.getInstance();

    }

}
