package p2;

public class Abcd {
	public float show()
	{
		System.out.println("Abcd.show() in p2 package");
		
		return (float)3.5;
	}
}
