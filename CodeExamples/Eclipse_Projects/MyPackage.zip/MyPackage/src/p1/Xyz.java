package p1;
//package statement should be always first line in the file

//public class can be accessed in this package and in other packages also
//non public class can be accessed only within current package
public class Xyz{
	public void display()
	{
		Internal my_obj = new Internal();
		System.out.println("Xyz.display() in p1 package");
	}
}










