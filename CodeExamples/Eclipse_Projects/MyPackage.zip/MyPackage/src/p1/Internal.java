package p1;

//Internal class can be accessed only with in current package, since it is
//non public class
class Internal{
	public Internal()
	{
		System.out.println("met1() in Internal class in p1 package");
	}
}