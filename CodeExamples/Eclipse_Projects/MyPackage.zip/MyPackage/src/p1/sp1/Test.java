package p1.sp1;

public class Test {
public void met()
{
	//Internal hd = new Internal();
	System.out.println("Test.met() in p1.sp1 package");
}
}
