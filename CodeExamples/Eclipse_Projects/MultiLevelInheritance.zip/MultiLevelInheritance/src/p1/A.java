package p1;

public class A {
	int i;
	
	protected int qrs;
	
	public A()
	{
		System.out.println("A() Constructor");
	}

	public A(int i)
	{
		System.out.println("A() Constructor overloaded");
	}
}
