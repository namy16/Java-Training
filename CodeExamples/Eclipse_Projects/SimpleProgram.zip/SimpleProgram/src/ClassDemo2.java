class Student{
	
}

public class ClassDemo2 {
	public static void main(String a[])
	{
		
	}
}
