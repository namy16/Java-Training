
class FirstMain{
	public static void main(String args[])
	{
		System.out.println("public static void main(String args[]) in FirstMain");
	}
}


public class TwoMainMethods {
	public static void main(String args[])
	{
		System.out.println("public static void main(String args[]) in TwoMainMethods");
	}
}
