public class Conditions{
public static void main(String args[])
{
	int i;
	
	System.out.println("Hello");
	for(i=0;i<10;i=i+2)
	{
		System.out.println(i);
		System.out.println("How r u?");
	}
	
	System.out.println("I am fine");
} 
}
