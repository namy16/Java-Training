
public class SystemEg {

	public static void main(String args[])
	{
		String version = System.getProperty("java.version");
		
		System.out.println("Java Version:"+version);
	}
}
