/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
  
  
public class LoginServlet extends HttpServlet {  
  
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
    String n=request.getParameter("userName");  
    String p=request.getParameter("userPass");  
         
    out.println("Before if statement");
    if(validateLogin(n, p))//success
    {  
        RequestDispatcher rd=request.getRequestDispatcher("WelcomeServlet"); 
        request.setAttribute("abc", "this_parameter_added_by_servlet");
        //forwards request to WelcomeServlet, and discards output from 
        //current servlet(if any)
        rd.forward(request, response);  
    }  
    else //failure
    {  
        out.print("Sorry UserName or Password Error!");  
        
        //instead of index.html, any servlet also can be used or included
        RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
        
        request.setAttribute("def", "this_parameter_added_by_servlet");
        
        //index.html page is included in the output along with message from current servlet 
        rd.include(request, response);  
        
        out.print("This is after include");                
        }  
    }  

    private boolean validateLogin(String usrnam, String passwd)
    {
        if(passwd.equals("simplepass") && usrnam.equalsIgnoreCase("JAVA652"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
  
}  