/**
 * Created by ADMIN on 7/28/17.
 */
public interface IArithService {
    int iadd(int x, int y);
    int isub(int x, int y);
    int imul(int x, int y);
}
