package com.mindtree.utility;

public interface Constants {

	String UNAME="com.mysql.jdbc.Driver";
	String URL= "jdbc:mysql://localhost:3306/data_base";
	String UID="root";
	String PASSWORD="root";
}
