package com.mindtree.application;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import com.mindtree.entity.Customer;
import com.mindtree.DAO.CustomerDao;
import com.mindtree.DAO.CustomerDaoImpl;

public class CustomerDetail {

	public static void main(String[] args) {
		int Cust_id = 0;
		String Cust_name = null;
		Date DOB = null;
		float amount = 0;
		int choice = 0;
		CustomerDao c = new CustomerDaoImpl();
		//Customer cus=new Customer();

		do {
			System.out.println("\nChoose Your Choices ...\n");
			System.out.println(" 1) List all customers \n");
			System.out.println("2) List customer based on id \n");
			System.out.println("3) Add customer \n");
			System.out.println("4) update customer \n");
			System.out.println("5) Remove customer \n");
			System.out.println("6) Add multiple customers \n");
			System.out.println("7) Exit \n");
			System.out.print("Enter your choice :  ");

			try {

				Scanner scanner = new Scanner(System.in);
				choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("List all customers\n");
					List<Customer> customers = c.getAllCustomers();
					for (Customer customer : customers) {

						System.out.println(customer);

					}

					break;
				case 2:
					System.out.println("Enter the customer id to find\n");
					int cus_id=scanner.nextInt();
					Customer cus=c.findCustomer(cus_id);
					System.out.println(cus);

					
					
					break;
				case 3:

					System.out.println("Add customer\n");
					System.out.println("Enter the customer id");
					Cust_id = scanner.nextInt();
					System.out.println("Enter the customer name");
					Cust_name = scanner.next();
					System.out.println("Enter the balance amount");
					amount = scanner.nextFloat();
					System.out.println("Enter the customer date of birth in dd/MM/YYYY");
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					try {
						DOB = df.parse(scanner.next());
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					java.sql.Date sqlDate = new java.sql.Date(DOB.getTime());
					Customer customer = new Customer(Cust_id, Cust_name, sqlDate, amount);
					boolean status = c.addCustomer(customer);
					if (status == true)
						System.out.println("User added succesfully");
					else
						System.out.println("User is not added");
					break;
				case 4:
					Customer d = new Customer();
					System.out.println("enter the customer name to be to update the older name");
					String customer_name = scanner.next();
					d.setCustomer_name(customer_name);
					System.out.println("enter the customer id to be updated");
					Cust_id = scanner.nextInt();
					
					boolean updateStaus = c.updateCustomer(Cust_id, d);

					if (updateStaus == true)
						System.out.println("User updated successfully");
					else
						System.out.println("User is not updated");

					break;
				case 5:
					// System.out.println("remove customer\n");
					System.out.println("enter the customer id to be deleted");
					Cust_id = scanner.nextInt();

					boolean delete = c.removeCustomer(Cust_id);

					if (delete == true)
						System.out.println("User deleted successfully");
					else
						System.out.println("User is not deleted");
					break;

				case 6:
					// System.out.println("add list customer\n");
					TreeSet<Customer> custom = new TreeSet<Customer>();
					System.out.println("Enter the number of customers to be added\n");
					int no_of_customer = scanner.nextInt();
					for (int i = 0; i < no_of_customer; i++) {
						System.out.println("Enter the customer id");
						Cust_id = scanner.nextInt();
						System.out.println("Enter the customer name");
						Cust_name = scanner.next();
						System.out.println("Enter the balance amount");
						amount = scanner.nextFloat();
						System.out.println("Enter the customer date of birth in dd/MM/YYYY");
						DateFormat df3 = new SimpleDateFormat("dd/MM/yyyy");
						try {
							DOB = df3.parse(scanner.next());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						java.sql.Date Date = new java.sql.Date(DOB.getTime());
						Customer custr = new Customer(Cust_id, Cust_name, Date, amount);
						custom.add(custr);

					}
					int addmul = c.addMultipleCustomers(custom);
					
				case 7: 
					System.out.println("Exit\n");
					System.exit(0);
					break;
					
				default:
					break;
					
				}
			} catch (Exception e) {
				System.out.println("Invalid input, enter the proper choice\n");

			}
		} while (choice != 6);
	}

}
