package com.mindtree.Comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.mindtree.DAO.CustomerDaoImpl;
import com.mindtree.entity.Customer;

public class SortMain {

	public static void main(String[] args) {
		CustomerDaoImpl customerDao = new CustomerDaoImpl();
		List<Customer> list = new ArrayList<Customer>();
		
		list = customerDao.getAllCustomers();
		
		Collections.sort(list, new SortByName());
		
		System.out.println(list);
		

	}

}
