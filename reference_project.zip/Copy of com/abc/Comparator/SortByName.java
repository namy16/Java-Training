package com.mindtree.Comparator;

import java.util.Comparator;

import com.mindtree.entity.Customer;

public class SortByName implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		return o1.getCustomer_name().compareTo(o2.getCustomer_name());
	}

}
