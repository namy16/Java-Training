package com.mindtree.entity;

import java.sql.Date;

public class Customer implements Comparable<Customer>{
	private int Customer_id;
	private String Customer_name;
	private Date Date_of_birth;
	private float Balance;

	public Customer(int customer_id, String customer_name, Date dOB, float balance) {
		super();
		this.Customer_id = customer_id;
		this.Customer_name = customer_name;
		this.Date_of_birth = dOB;
		this.Balance = balance;
	}

	public Customer() {
		super();
	}

	public int getCustomer_id() {
		return Customer_id;
	}

	public void setCustomer_id(int customer_id) {
		Customer_id = customer_id;
	}

	public String getCustomer_name() {
		return Customer_name;
	}

	public void setCustomer_name(String customer_name) {
		Customer_name = customer_name;
	}

	public Date getDate_of_birth() {
		return Date_of_birth;
	}

	public void setDate_of_birth(java.sql.Date date_of_birth) {
		Date_of_birth = date_of_birth;
	}

	public float getBalance() {
		return Balance;
	}

	public void setBalance(float balance) {
		Balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [Customer_id=" + Customer_id + ", Customer_name=" + Customer_name + ", Date_of_birth="
				+ Date_of_birth + ", Balance=" + Balance + "]";
	}

	@Override
	public int compareTo(Customer o) {
		if(Customer_id>o.getCustomer_id()){
			return 1;
		}
		else if(Customer_id<o.getCustomer_id()){
			return -1;
		}else{
		return 0;
		}
	}

	

}
