package com.mindtree.DAO;

import java.util.List;
import java.util.TreeSet;

import com.mindtree.entity.Customer;

public interface CustomerDao {
	public List<Customer> getAllCustomers();
	public Customer findCustomer(int customerId);
	public  boolean addCustomer(Customer c);
	public boolean updateCustomer(int customerId,Customer c);
	public boolean removeCustomer(int customerId);
	public int addMultipleCustomers(TreeSet<Customer> list);

}
