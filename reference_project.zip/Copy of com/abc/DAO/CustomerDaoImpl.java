package com.mindtree.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import com.mindtree.entity.Customer;
import com.mindtree.utility.JdbcHelper;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		List<Customer> customerList = null;
		try {
			con = JdbcHelper.getConnection();
			String sql = "select * from customer";
			ps_sel = con.prepareStatement(sql);
			ps_sel.execute();
			rs = ps_sel.getResultSet();

			Customer customer = null;
			customerList = new ArrayList<Customer>();

			while (rs.next()) {
				customer = new Customer(rs.getInt("Customer_id"), rs.getString("Customer_name"),
						rs.getDate("Date_of_birth"), rs.getFloat("Balance"));
				customerList.add(customer);
			}
			return customerList;

		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return null;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}
	}

	@Override
	public Customer findCustomer(int customerId) {
		Customer customer = null;
		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		
		try {
			con = JdbcHelper.getConnection();
			String sql = "select * from customer where Customer_id=? ";
			ps_sel = con.prepareStatement(sql);
			ps_sel.setInt(1, customerId);
			ps_sel.execute();
			rs = ps_sel.getResultSet();
			

			if (rs.next())
			{
				customer = new Customer();
                customer.setCustomer_id(rs.getInt("Customer_id"));
                customer.setCustomer_name(rs.getString("Customer_name"));
                customer.setDate_of_birth(rs.getDate("Date_of_birth"));
                customer.setBalance(rs.getFloat("Balance"));
              
			}
			return customer;

		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return null;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}
	}

	@Override
	public boolean addCustomer(Customer c) {
		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		try {
			con = JdbcHelper.getConnection();
			con.setAutoCommit(false);

			String cus_sql = "insert into customer(Customer_id,Customer_name,Date_of_birth,Balance) values(?,?,?,?)";
			ps_sel = con.prepareStatement(cus_sql);
			ps_sel.setInt(1, c.getCustomer_id());
			ps_sel.setString(2, c.getCustomer_name());
			ps_sel.setDate(3, c.getDate_of_birth());
			ps_sel.setFloat(4, c.getBalance());
			ps_sel.executeUpdate();

			con.commit();
			return true;
		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return false;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}

	}

	@Override
	public boolean updateCustomer(int customerId, Customer c) {

		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		try {
			con = JdbcHelper.getConnection();
			con.setAutoCommit(false);
			String cus_sql = "update customer set Customer_name=? where customer_id=?";
			ps_sel = con.prepareStatement(cus_sql);

			ps_sel.setString(1, c.getCustomer_name());
			ps_sel.setInt(2, customerId);
			ps_sel.executeUpdate();

			con.commit();
			return true;
		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return false;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}

	}

	@Override
	public boolean removeCustomer(int customerId) {
		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		try {
			con = JdbcHelper.getConnection();
			con.setAutoCommit(false);
			String cus_sql = "Delete from customer where customer_id=?";
			ps_sel = con.prepareStatement(cus_sql);
			ps_sel.setInt(1, customerId);

			ps_sel.executeUpdate();

			con.commit();
			return true;
		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return false;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}

	}

	@Override
	public int addMultipleCustomers(TreeSet<Customer> list) {
		Connection con = null;
		PreparedStatement ps_sel = null;
		ResultSet rs = null;
		try {
			con = JdbcHelper.getConnection();
			con.setAutoCommit(false);
			String cus_sql = "insert into customer(Customer_id,Customer_name,Date_of_birth,Balance) values(?,?,?,?)";
			ps_sel = con.prepareStatement(cus_sql);
			for (Customer customer : list) {

				ps_sel.setInt(1, customer.getCustomer_id());
				ps_sel.setString(2, customer.getCustomer_name());
				ps_sel.setDate(3, customer.getDate_of_birth());
				ps_sel.setFloat(4, customer.getBalance());
				ps_sel.addBatch();
			}
			ps_sel.executeBatch();
			con.commit();
			return 1;
		} catch (SQLException e) {
			System.out.println("OOPs error occured in connecting database " + e.getMessage());
			return 0;
		} finally {
			JdbcHelper.close(rs);
			JdbcHelper.close(ps_sel);
			JdbcHelper.close(con);
		}
	}

}
